/**
 * @file bst_functions.cpp
 * @brief Implementasi fungsi-fungsi untuk Binary Search Tree (BST)
 *
 * File ini berisi implementasi fungsi-fungsi:
 * - findMin: mencari node dengan nilai terkecil dalam BST
 * - findMax: mencari node dengan nilai terbesar dalam BST
 * - height: menghitung tinggi/kedalaman maksimum dari BST
 * - countLeaves: menghitung jumlah node daun (leaf) dalam BST
 */

#include <iostream>

// Definisi struktur Node untuk Binary Search Tree
struct Node {
    int data;         // Nilai yang disimpan pada node
    Node* left;       // Pointer ke anak kiri
    Node* right;      // Pointer ke anak kanan

    // Constructor
    Node(int value) {
        data = value;
        left = nullptr;
        right = nullptr;
    }
};

/**
 * @brief Mencari node dengan nilai terkecil dalam BST
 *
 * Fungsi ini mencari node dengan nilai terkecil dalam BST dengan
 * cara traversal ke kiri sampai menemukan node paling kiri
 * (yang tidak memiliki anak kiri lagi).
 *
 * @param root Pointer ke root node dari BST atau sub-tree
 * @return Node* Pointer ke node dengan nilai terkecil
 *
 * Contoh:
 *     Untuk BST:      10
 *                   /    \
 *                  5     15
 *                 / \    / \
 *                3   7  12  20
 *
 *     findMin(root) akan mengembalikan node dengan nilai 3
 */
Node* findMin(Node* root) {
    // Basis kasus: tree kosong
    if (root == nullptr) {
        return nullptr;
    }

    // Jika tidak ada anak kiri, maka root saat ini adalah nilai terkecil
    if (root->left == nullptr) {
        return root;
    }

    // Rekursif mencari nilai terkecil di sub-tree kiri
    return findMin(root->left);
}

/**
 * @brief Mencari node dengan nilai terbesar dalam BST
 *
 * Fungsi ini mencari node dengan nilai terbesar dalam BST dengan
 * cara traversal ke kanan sampai menemukan node paling kanan
 * (yang tidak memiliki anak kanan lagi).
 *
 * @param root Pointer ke root node dari BST atau sub-tree
 * @return Node* Pointer ke node dengan nilai terbesar
 *
 * Contoh:
 *     Untuk BST:      10
 *                   /    \
 *                  5     15
 *                 / \    / \
 *                3   7  12  20
 *
 *     findMax(root) akan mengembalikan node dengan nilai 20
 */
Node* findMax(Node* root) {
    // Basis kasus: tree kosong
    if (root == nullptr) {
        return nullptr;
    }

    // Jika tidak ada anak kanan, maka root saat ini adalah nilai terbesar
    if (root->right == nullptr) {
        return root;
    }

    // Rekursif mencari nilai terbesar di sub-tree kanan
    return findMax(root->right);
}

/**
 * @brief Menghitung tinggi/kedalaman maksimum dari BST
 *
 * Fungsi ini menghitung tinggi/kedalaman maksimum dari BST, yang
 * didefinisikan sebagai jumlah maksimum edge dari root ke daun.
 * Tree kosong memiliki tinggi -1, sedangkan tree dengan hanya root
 * memiliki tinggi 0.
 *
 * @param root Pointer ke root node dari BST atau sub-tree
 * @return int Tinggi dari BST
 *
 * Contoh:
 *     Untuk BST:      10
 *                   /    \
 *                  5     15
 *                 / \    / \
 *                3   7  12  20
 *
 *     height(root) akan mengembalikan 2
 */
int height(Node* root) {
    // Basis kasus: tree kosong
    if (root == nullptr) {
        return -1;
    }

    // Hitung tinggi sub-tree kiri dan kanan
    int leftHeight = height(root->left);
    int rightHeight = height(root->right);

    // Tinggi tree adalah tinggi maksimum antara sub-tree kiri dan kanan + 1
    return std::max(leftHeight, rightHeight) + 1;
}

/**
 * @brief Menghitung jumlah node daun (leaf) dalam BST
 *
 * Fungsi ini menghitung jumlah node daun dalam BST.
 * Leaf adalah node yang tidak memiliki anak kiri dan anak kanan.
 *
 * @param root Pointer ke root node dari BST atau sub-tree
 * @return int Jumlah leaf node dalam BST
 *
 * Contoh:
 *     Untuk BST:      10
 *                   /    \
 *                  5     15
 *                 / \    / \
 *                3   7  12  20
 *
 *     countLeaves(root) akan mengembalikan 4 (node 3, 7, 12, dan 20 adalah leaf)
 */
int countLeaves(Node* root) {
    // Basis kasus: tree kosong
    if (root == nullptr) {
        return 0;
    }

    // Jika node adalah leaf (tidak memiliki anak kiri dan kanan)
    if (root->left == nullptr && root->right == nullptr) {
        return 1;
    }

    // Rekursif menghitung jumlah leaf di sub-tree kiri dan kanan
    return countLeaves(root->left) + countLeaves(root->right);
}

// Fungsi untuk membuat dan menampilkan tree sebagai contoh
void testBSTFunctions() {
    // Membuat BST seperti:
    //         10
    //       /    \
    //      5     15
    //     / \    / \
    //    3   7  12  20

    Node* root = new Node(10);
    root->left = new Node(5);
    root->right = new Node(15);
    root->left->left = new Node(3);
    root->left->right = new Node(7);
    root->right->left = new Node(12);
    root->right->right = new Node(20);

    // Test findMin
    Node* min = findMin(root);
    std::cout << "Nilai terkecil: " << (min ? min->data : -1) << std::endl;

    // Test findMax
    Node* max = findMax(root);
    std::cout << "Nilai terbesar: " << (max ? max->data : -1) << std::endl;

    // Test height
    std::cout << "Tinggi tree: " << height(root) << std::endl;

    // Test countLeaves
    std::cout << "Jumlah daun: " << countLeaves(root) << std::endl;

    // Pembersihan memori (dealokasi)
    // Implementasi fungsi pembersihan memori di sini (tidak ditampilkan)
}

int main() {
    testBSTFunctions();
    return 0;
}
